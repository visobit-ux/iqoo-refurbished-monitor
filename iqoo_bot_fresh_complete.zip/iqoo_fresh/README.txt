iQOO Refurbished Telegram bot — updated scripts

Files:
- monitor.py: searches the iQOO store for "refurbished" and sends a Telegram alert when a result becomes available.
- hourly_status.py: sends the product names, prices, links and status from those same search-result cards once per hour.

Important:
1. Replace the existing monitor.py and hourly_status.py in the GitHub repository with these files.
2. Keep the existing GitHub Secrets TELEGRAM_BOT_TOKEN and TELEGRAM_CHAT_ID. Do not put tokens in code.
3. The scripts only use product cards from the search results; they do not build a product list from unrelated pages.
4. If search results cannot be detected, the script reports an error rather than claiming that Compare Models is a product.
5. On search results, a visible price with no Sold Out badge is treated as In Stock. If the site's badge/text changes, status parsing may need adjustment.
